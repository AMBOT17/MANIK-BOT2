const kerangmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}apakah [optional]*
╰─➤ *${prefix}rate [optional]*
╰─➤ *${prefix}bisakah [optional]*
╰─➤ *${prefix}kapankah [optional]*
╰─➤ *${prefix}gantengcek*
╰─➤ *${prefix}toxic*
╰─➤ *${prefix}cantikcek*
╰─➤ *${prefix}persengay*
╭┈─────DHIMAS
╰─❁۪۪`
}
exports.kerangmenu = kerangmenu