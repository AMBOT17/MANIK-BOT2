let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Axsis [083141727903]
│ • Dana [083141727903] (iky ganteng )
╰────
Donasi ajg jng cuma pake doang heheh:(
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
