const kerangmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}atm*
╰─➤ *${prefix}limit*
╰─➤ *${prefix}transfer*
╰─➤ *${prefix}buylimit*
╰─➤ *${prefix}gantengcek*
╰─➤ *${prefix}toxic*
╰─➤ *${prefix}cantikcek*
╰─➤ *${prefix}persengay*
╭┈─────MANIK
╰─❁۪۪`
}
exports.kerangmenu = kerangmenu