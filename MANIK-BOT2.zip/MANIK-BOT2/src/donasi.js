const donasi = (pushname, prefix, botName, ownerName) => { 
	return `Hallo, ${pushname} 👋
Mau donasi ya kak ✨
 اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّبةٍ
_“jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016]_
╔════════════════════
║ *DONASI UNTUK ${botName}*
╠════════════════════
║╭──❉ *DONASI BANG* ❉─────
║│➸ *OVO*: GADA OVO 
║│➸ *DANA*: DANA BEKU 2X
║│➸ *PULSA*:085737134572
║│➸ *GOPAY*: 085737134572
╠════════════════════
║ _*POWERED BY ${ownerName}*_
╚════════════════════`
}

exports.donasi = donasi