const makermenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}tahta* [MANIK]
╰─➤ *${prefix}logo* [MANIK]
╰─➤ *${prefix}goldbutton* [MANIK]
╰─➤ *${prefix}silverbutton* [MANIK]
╰─➤ *${prefix}pronlogo* [text|text]
╰─➤ *${prefix}snow* [text|text]
╰─➤ *${prefix}marvelogo* [text|text]
╰─➤ *${prefix}text3d* [MANIK]
╰─➤ *${prefix}ninjalogo* [text|text]
╰─➤ *${prefix}wolflogo* [text|text]
╰─➤ *${prefix}lionlogo* [text|text]
╰─➤ *${prefix}textscreen* [text
╰─➤ *${prefix}rtext* [MANIK]
╰─➤ *${prefix}party* [MANIK]
╰─➤ *${prefix}light* [MANIK]
╰─➤ *${prefix}shadow* [MANIK]
╰─➤ *${prefix}minion* [MANIK]
╰─➤ *${prefix}neon* [MANIK]
╰─➤ *${prefix}neongreen* [MANIK]
╰─➤ *${prefix}neon2* [MANIK]
╰─➤ *${prefix}3d* [MANIK]
╰─➤ *${prefix}blackpink* [MANIK]
╰─➤ *${prefix}sandwriting* [MANIK]
╰─➤ *${prefix}water* [text|text]
╰─➤ *${prefix}thunder* [MANIK]
╰─➤ *${prefix}stiltext* [text|text]
╰─➤ *${prefix}party* [MANIK]
╰─➤ *${prefix}galaxtext* [MANIK]
╰─➤ *${prefix}lovemake* [MANIK]
╰─➤ *${prefix}walpaperhd* [MANIK]
╰─➤ *${prefix}fire* [MANIK]
╰─➤ *${prefix}quotemaker* [tx|tx|random]
╰─➤ *${prefix}water* [MANIK]
╰─➤ *${prefix}epep* [MANIK]
╰─➤ *${prefix}glitch* [MANIK]
╰─➤ *${prefix}jokerlogo [MANIK]*
╭┈─────MANIK
╰─❁۪۪`
}
exports.makermenu = makermenu