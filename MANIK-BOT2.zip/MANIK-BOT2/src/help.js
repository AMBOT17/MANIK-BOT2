const help = (prefix) => { 
	return `

╭────┈ ↷
┃□│✎┊*MANIK BOT*
┃□│╭────────╯
┃□││⊱❥ *V 6.0*
┃□││⊱❥ *MANIK GANS*             
┃□││⊱❥ *103823 USER*
╰─────────────────┈ ❁ཻུ۪۪⸙͎  
╭┈──────*RULES*──────❁۪۪
╰─➤⚒RULES📜
↣TLPN=BLOCK+BAN
↣SPAM=BAN
↣JEDA 3 DETIK
─────────────────┈ ❁۪۪
╭┈────*FULL FITUR*─────❁۪۪
╰─❁۪۪
╰─➤ *${prefix}admin menu*
╰─➤ *${prefix}maker menu*
╰─➤ *${prefix}kerang menu*
╰─➤ *${prefix}media menu*
╰─➤ *${prefix}anime menu*
╰─➤ *${prefix}group menu*
╰─➤ *${prefix}fun menu*
╰─➤ *${prefix}owner menu*
╰─➤ *${prefix}other menu*
╰─➤ *${prefix}nsfw menu*
╰─➤ *${prefix}vip menu*
─────────────────┈ ❁۪۪
╭┈────OTHER MENU
╰─❁۪۪
╰─➤ *${prefix}owner*
╰─➤ *${prefix}info*
╰─➤ *${prefix}rules*
╰─➤ *${prefix}donasi*
╰─➤ *${prefix}listvip*
╰─➤ *${prefix}cekvip*
╰─➤ *${prefix}sewabot*
╰─➤ *${prefix}rules*
───────────────────┈ ❁۪۪
     SEWA BOT?DAFTAR VIP?
     PC: wa.me/62895379489966
╭┈─────────────────┈ ❁۪۪
╰─➤Intro DHIMAS
Nama lengkap : *ARYA MANIK*
Umur  : *AKU MASIH IMUT*
Alamat  : *KLEAN GABAKAL SINI JUGA:V*
Whsatsapp : wa.me/6285737134572
─────────────────┈ ❁۪۪
                   ©️ *BY* *MANIK*

`
}
exports.help = help
