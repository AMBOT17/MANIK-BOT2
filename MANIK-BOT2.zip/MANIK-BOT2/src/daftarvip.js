const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6285737134572 atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP FAN BOT MANIK :*
_https://chat.whatsapp.com/J29q38KJIyo8gSbznvN2E3_ `
}
exports.daftarvip = daftarvip